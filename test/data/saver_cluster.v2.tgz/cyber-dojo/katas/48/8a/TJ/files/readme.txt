Write a program that prints the numbers from 1 to 100.
But for multiples of three print "Fizz" instead of the number,
for multiples of five print "Buzz", and for numbers which are
multiples of both three and five print "FizzBuzz".
