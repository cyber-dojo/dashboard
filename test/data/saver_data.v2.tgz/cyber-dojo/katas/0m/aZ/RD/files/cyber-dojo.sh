chmod 700 *.sh
./test_hiker.sh
