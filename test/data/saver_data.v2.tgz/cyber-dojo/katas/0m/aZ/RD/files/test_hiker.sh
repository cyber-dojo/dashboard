#!/usr/bin/env bats

source ./hiker.sh

@test "1 gives 1" {
  [ "$(fizz_buzz 1)" = "1" ]
}

@test "3 gives Fizz" {
  [ "$(fizz_buzz 3)" = "Fizz" ]
}

@test "5 gives Buzz" {
  [ "$(fizz_buzz 5)" = "Buzz" ]
}

@test "15 gives FizzBuzz" {
  [ "$(fizz_buzz 15)" = "FizzBuzz" ]
}
