#!/bin/bash

answer()
{
  echo $((6 * 7))
}

#comment
#comment